﻿$(function () {
    //Fancybox
    $('#login-link').fancybox({
        showCloseButton: false,
        overlayColor: '#000',
        opacity: 0.3,
        autoDimensions: false,
        height: 260
    });
})
